import React from "react";
import { ArrowRight, LineChart, Sparkles } from "lucide-react";
import { Link } from "react-router-dom";
import SectorCards from "../components/SectorCards";
import DashboardPreview from "../components/DashboardPreview";

const HeroPage: React.FC = () => {
  return (
    <div className="mx-auto max-w-6xl px-4 py-10 space-y-12 bg-white">
      <div className="flex flex-col gap-10 md:flex-row md:items-center">
        <div className="flex-1 space-y-6">
          <div className="inline-flex items-center gap-2 rounded-full border border-emerald-500/40 bg-emerald-500/10 px-3 py-1 text-[11px] text-emerald-700">
            <Sparkles className="h-3 w-3" />
            <span>KOBİ Finans · Yapay Zeka Destekli FINOPS Platformu</span>
          </div>

          <h1 className="text-3xl font-semibold tracking-tight text-gray-900 md:text-4xl lg:text-5xl">
            Veri kaosuna son verin,
            <span className="block bg-gradient-to-r from-blue-500 via-cyan-500 to-emerald-500 bg-clip-text text-transparent">
              kârlılığınızı artırın.
            </span>
          </h1>

          <p className="max-w-xl text-sm leading-relaxed text-gray-600">
            FINOPS AI Studio; Turizm/Otel, Restoran/Cafe, Sağlık, Perakende,
            Otomotiv ve Tarım işletmeleri için nakit akışı, stok maliyeti, bütçe
            ve kârlılık analizlerini tek bir ekranda toplar.
          </p>

          <div className="flex flex-wrap items-center gap-3">
            <Link
              to="/dashboards"
              className="inline-flex items-center gap-2 rounded-full bg-blue-600 px-4 py-2 text-xs font-semibold text-white shadow-lg shadow-blue-200/80 hover:bg-blue-500"
            >
              Dashboardları incele
              <ArrowRight className="h-3 w-3" />
            </Link>
            <Link
              to="/pricing"
              className="text-xs font-medium text-gray-600 underline-offset-4 hover:text-gray-900 hover:underline"
            >
              Fiyatları gör (₺ bazlı faturalama)
            </Link>
          </div>

          <div className="flex flex-wrap items-center gap-4 text-[11px] text-gray-500">
            <div className="flex items-center gap-2">
              <LineChart className="h-3 w-3 text-emerald-500" />
              <span>Gerçek zamanlı nakit akışı & kârlılık</span>
            </div>
            <span className="h-1 w-1 rounded-full bg-gray-300" />
            <span>Logo, Netsis, Mikro, Paraşüt entegrasyonuna hazır mimari*</span>
          </div>
        </div>

        <div className="flex-1 space-y-4">
          {/* Finansal Özet */}
          <div className="rounded-2xl border border-gray-200 bg-gray-50/80 p-4 shadow-xl shadow-gray-200/70 text-[11px]">
            <div className="mb-3 flex items-center justify-between">
              <div>
                <div className="text-xs font-medium text-gray-800">
                  Aylık Finansal Özet
                </div>
                <div className="text-[11px] text-gray-500">Tüm işletmeler · Toplam</div>
              </div>
              <div className="rounded-full bg-emerald-100 px-3 py-1 text-[11px] text-emerald-800 font-medium">
                +%22,4 büyüme
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 text-[11px]">
              <div className="space-y-1 rounded-xl bg-white p-3 border border-gray-200/80">
                <div className="text-gray-500">Ciro</div>
                <div className="text-sm font-semibold text-gray-900">₺3.250.000</div>
                <div className="text-[10px] text-emerald-600">+%18,2 önceki aya göre</div>
              </div>

              <div className="space-y-1 rounded-xl bg-white p-3 border border-gray-200/80">
                <div className="text-gray-500">Net Kâr</div>
                <div className="text-sm font-semibold text-gray-900">₺254.000</div>
                <div className="text-[10px] text-emerald-600">Net marj: %7,8</div>
              </div>

              <div className="space-y-1 rounded-xl bg-white p-3 border border-gray-200/80">
                <div className="text-gray-500">Nakit Pozisyonu</div>
                <div className="text-sm font-semibold text-gray-900">₺1.850.000</div>
                <div className="text-[10px] text-sky-600">12 haftalık runway</div>
              </div>

              <div className="space-y-1 rounded-xl bg-white p-3 border border-gray-200/80">
                <div className="text-gray-500">Stok Maliyeti</div>
                <div className="text-sm font-semibold text-gray-900">₺970.000</div>
                <div className="text-[10px] text-amber-600">Hedefe göre +%4,2</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <SectorCards />
      <DashboardPreview />
    </div>
  );
};

export default HeroPage;
