import { Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import HeroPage from './pages/HeroPage'; // Corrected import
import DashboardsPage from './pages/DashboardsPage';
import FeaturesPage from './pages/FeaturesPage';
import SupportPage from './pages/SupportPage';

function App() {
  return (
    <div className="App">
      <Navbar />
      <main className="pt-16">
        <Routes>
          <Route path="/" element={<HeroPage />} /> {/* Corrected component */}
          <Route path="/dashboards" element={<DashboardsPage />} />
          <Route path="/features" element={<FeaturesPage />} />
          <Route path="/support" element={<SupportPage />} />
        </Routes>
      </main>
    </div>
  );
}

export default App;
