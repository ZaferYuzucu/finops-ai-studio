import { Link, NavLink } from "react-router-dom";
import { ChevronDown } from "lucide-react";

const navConfig = [
  { 
    name: "Çözümler", 
    href: "/solutions", 
    children: [
      { name: "Finansal Veri Analizi", href: "/solutions/financial-data-analysis" },
      { name: "Maliyet ve Stok Yönetimi", href: "/solutions/cost-inventory-management" },
      { name: "Nakit Akışı-Cash Flow", href: "/solutions/cash-flow" },
      { name: "Bütçe ve Planlama", href: "/solutions/budgeting-planning" },
      { name: "İK- Bordo / Performans Değerleme", href: "/solutions/hr-performance" },
    ] 
  },
  {
    name: "Veri Görselleştirme",
    href: "/dashboards",
    children: [
      { name: "Özellikler", href: "/features" },
      { name: "Destek", href: "/support" },
      { name: "Dashboard Örnekleri", href: "/dashboards" },
    ],
  },
  { 
    name: "Kaynaklar", 
    href: "/resources", 
    children: [
      { name: "Bilgi Merkezi", href: "/blog" }, 
      { name: "Dökümanlar", href: "/docs" }]
  },
  { name: "Fiyatlandırma", href: "/pricing" },
];

export default function Navbar() {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-md border-b border-gray-200">
      <nav className="container mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex-shrink-0">
            <Link to="/" className="flex items-center gap-2">
              <img src="/public/finops-logo-dark.png" alt="Finops AI Logo" className="h-7 w-auto" />
              <span className="text-gray-800 font-semibold text-base tracking-wide">Finops AI</span>
            </Link>
          </div>
          <div className="hidden md:flex items-center space-x-2">
            {navConfig.map((item) => (
              <div key={item.name} className="relative group">
                {item.children ? (
                  <>
                    <button className="px-4 py-2 flex items-center gap-1 text-sm font-medium text-gray-600 hover:text-blue-600 transition-colors">{item.name} <ChevronDown className="h-4 w-4" /></button>
                    <div className="absolute top-full left-0 mt-1 w-64 rounded-md shadow-lg bg-white ring-1 ring-gray-200 p-2 z-10 hidden group-hover:block">
                      {item.children.map((child) => (
                        <NavLink
                          key={child.name}
                          to={child.href}
                          className={({ isActive }) =>
                            `block px-3 py-2 rounded-md text-sm transition-colors ${
                              isActive ? "text-white bg-blue-600" : "text-gray-700 hover:bg-gray-100"
                            }`
                          }
                        >
                          {child.name}
                        </NavLink>
                      ))}
                    </div>
                  </>
                ) : (
                  <NavLink
                    to={item.href}
                    className={({ isActive }) =>
                      `px-4 py-2 rounded-md text-sm font-medium transition-colors hover:text-blue-600 ${
                        isActive ? "text-blue-600 font-semibold" : "text-gray-600"
                      }`
                    }
                  >
                    {item.name}
                  </NavLink>
                )}
              </div>
            ))}
          </div>
          <div className="flex items-center gap-4">
            <Link to="/login" className="hidden sm:inline-block text-sm text-gray-600 hover:text-gray-900 transition-colors">Giriş Yap</Link>
            <Link to="/contact" className="rounded-md bg-blue-600 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-blue-500 transition-all duration-200">Demo Talep Et</Link>
          </div>
        </div>
      </nav>
    </header>
  );
}
