
import React from 'react';
import { Link } from 'react-router-dom';

const PrivacyPolicyPage: React.FC = () => {
  const SectionTitle: React.FC<{ children: React.ReactNode }> = ({ children }) => (
    <h2 className="mt-12 text-2xl font-bold tracking-tight text-gray-900 sm:text-3xl">{children}</h2>
  );

  const SectionParagraph: React.FC<{ children: React.ReactNode }> = ({ children }) => (
    <p className="mt-4 leading-7">{children}</p>
  );

  const ListItem: React.FC<{ children: React.ReactNode }> = ({ children }) => (
    <li className="flex gap-x-3">
      <svg className="mt-1 h-5 w-5 flex-none text-blue-600" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.857-9.809a.75.75 0 00-1.214-.882l-3.483 4.79-1.88-1.88a.75.75 0 10-1.06 1.061l2.5 2.5a.75.75 0 001.137-.089l4-5.5z" clipRule="evenodd" />
      </svg>
      <span>{children}</span>
    </li>
  );

  return (
    <div className="bg-white px-6 py-24 sm:py-32 lg:px-8">
      <div className="mx-auto max-w-3xl text-base leading-7 text-gray-700">
        <p className="text-base font-semibold leading-7 text-blue-600">Son Güncelleme: 13 Aralık 2025</p>
        <h1 className="mt-2 text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">Kişisel Verilerin Korunması ve İşlenmesi Politikası (Aydınlatma Metni)</h1>
        <p className="mt-6 text-xl leading-8">
          Bu metin, FINOPS AI (“FINOPS AI”, “Şirket”, “biz”) olarak, 6698 sayılı Kişisel Verilerin Korunması Kanunu (“KVKK”) uyarınca, “Veri Sorumlusu” sıfatıyla, müşterilerimiz ve platformumuzu kullanan ziyaretçilerimizin (“İlgili Kişi”) kişisel verilerini nasıl işlediğimize dair sizi bilgilendirmek amacıyla hazırlanmıştır.
        </p>

        <div className="mt-10 max-w-2xl">
          <SectionTitle>1. Veri Sorumlusunun Kimliği</SectionTitle>
          <SectionParagraph>
            KVKK kapsamında Şirketimiz, "Veri Sorumlusu" olarak hareket etmektedir.
            <br />
            <strong>Ticari Unvan:</strong> FINOPS AI Yazılım ve Teknoloji Anonim Şirketi
            <br />
            <strong>İletişim Adresi:</strong> <Link to="/contact" className="text-blue-600 hover:text-blue-700">İletişim Sayfası</Link>
          </SectionParagraph>

          <SectionTitle>2. İşlenen Kişisel Veriler ve İşleme Amaçları</SectionTitle>
          <SectionParagraph>
            Sunduğumuz hizmetler kapsamında sizden topladığımız kişisel veriler ve bu verileri işleme amaçlarımız aşağıda detaylandırılmıştır:
          </SectionParagraph>
          <ul role="list" className="mt-8 max-w-xl space-y-6 text-gray-600">
            <ListItem>
              <strong>Kimlik ve İletişim Bilgileri (Ad, Soyad, E-posta, Telefon):</strong> Kullanıcı hesabı oluşturmak, hizmetlerimizi sunmak, faturalandırma yapmak, destek sağlamak ve sizinle iletişim kurmak.
            </ListItem>
            <ListItem>
              <strong>Finansal Veriler ve Müşteri İşlem Bilgileri:</strong> Abonelik ve ödeme süreçlerini yönetmek, finansal raporlama hizmetlerini sunmak, yasal yükümlülükleri yerine getirmek.
            </ListItem>
             <ListItem>
              <strong>Kullanım ve Log Verileri:</strong> Hizmetlerimizi iyileştirmek, performansı analiz etmek, güvenlik tehditlerini tespit etmek ve kullanıcı deneyimini optimize etmek.
            </ListItem>
            <ListItem>
              <strong>Pazarlama Bilgileri:</strong> İzniniz dahilinde size yeni hizmetlerimiz, kampanyalar ve güncellemeler hakkında bilgi vermek.
            </ListItem>
          </ul>

          <SectionTitle>3. Kişisel Veri Toplamanın Yöntemi ve Hukuki Sebebi</SectionTitle>
          <SectionParagraph>
            Kişisel verileriniz, platformumuza kayıt olmanız, formları doldurmanız, hizmetlerimizi kullanmanız gibi otomatik veya otomatik olmayan yollarla toplanmaktadır. Bu veriler, KVKK Madde 5’te belirtilen aşağıdaki hukuki sebeplere dayalı olarak işlenmektedir:
          </SectionParagraph>
          <ul role="list" className="mt-8 max-w-xl space-y-6 text-gray-600">
            <ListItem>Sözleşmenin kurulması veya ifasıyla doğrudan doğruya ilgili olması.</ListItem>
            <ListItem>Veri sorumlusunun hukuki yükümlülüğünü yerine getirebilmesi için zorunlu olması.</ListItem>
            <ListItem>İlgili kişinin temel hak ve özgürlüklerine zarar vermemek kaydıyla, veri sorumlusunun meşru menfaatleri için veri işlenmesinin zorunlu olması.</ListItem>
            <ListItem>Açık rızanızın bulunması (örn. pazarlama faaliyetleri için).</ListItem>
          </ul>
          
          <SectionTitle>4. Kişisel Verilerin Aktarılması</SectionTitle>
          <SectionParagraph>
             Kişisel verileriniz, yasal sınırlar çerçevesinde ve yalnızca gerekli olduğu durumlarda; altyapı sağlayıcıları (sunucu, bulut bilişim), ödeme kuruluşları, iş ortakları, yasal danışmanlar ve kanunen yetkili kamu kurumları ile paylaşılabilmektedir. Veriler, KVKK Madde 8 ve 9’da belirtilen şartlara uygun olarak yurt içine ve/veya yurt dışına aktarılabilir.
          </SectionParagraph>

          <SectionTitle>5. İlgili Kişinin Hakları (KVKK Madde 11)</SectionTitle>
          <SectionParagraph>
            KVKK’nın 11. maddesi uyarınca aşağıdaki haklara sahipsiniz:
          </SectionParagraph>
          <ul role="list" className="mt-8 max-w-xl space-y-6 text-gray-600">
            <ListItem>Kişisel verilerinizin işlenip işlenmediğini öğrenme,</ListItem>
            <ListItem>İşlenmişse buna ilişkin bilgi talep etme,</ListItem>
            <ListItem>İşlenme amacını ve amacına uygun kullanılıp kullanılmadığını öğrenme,</ListItem>
            <ListItem>Yurt içinde veya yurt dışında verilerin aktarıldığı üçüncü kişileri bilme,</ListItem>
            <ListItem>Eksik veya yanlış işlenmişse düzeltilmesini isteme,</ListItem>
            <ListItem>KVKK’nın 7. maddesinde öngörülen şartlar çerçevesinde silinmesini veya yok edilmesini isteme,</ListItem>
            <ListItem>Yapılan işlemlerin, verilerin aktarıldığı üçüncü kişilere bildirilmesini isteme,</ListItem>
            <ListItem>İşlenen verilerin münhasıran otomatik sistemler vasıtasıyla analiz edilmesi suretiyle aleyhinize bir sonucun ortaya çıkmasına itiraz etme,</ListItem>
            <ListItem>Kanuna aykırı olarak işlenmesi sebebiyle zarara uğramanız hâlinde zararın giderilmesini talep etme.</ListItem>
          </ul>
          <SectionParagraph>
            Bu haklarınızı kullanmak için <Link to="/contact" className="text-blue-600 hover:text-blue-700">iletişim sayfamız</Link> üzerinden bize başvurabilirsiniz.
          </SectionParagraph>

          <SectionTitle>6. Çerez Politikası</SectionTitle>
          <SectionParagraph>
            Web sitemizde ve platformumuzda kullanılan çerezler hakkında detaylı bilgi için lütfen <Link to="/legal/cookie-policy" className="text-blue-600 hover:text-blue-700">Çerez Politikamızı</Link> inceleyiniz.
          </SectionParagraph>

          <SectionTitle>7. Politika Değişiklikleri</SectionTitle>
          <SectionParagraph>
            FINOPS AI, bu politikada yasal düzenlemelere ve Şirket politikalarına bağlı olarak değişiklik yapma hakkını saklı tutar. Yapılan değişiklikler, bu sayfada yayınlandığı tarihte yürürlüğe girer.
          </SectionParagraph>
        </div>
      </div>
    </div>
  );
};

export default PrivacyPolicyPage;
