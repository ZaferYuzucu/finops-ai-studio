import React from 'react';
import { Link } from 'react-router-dom';

const CookiePolicyPage: React.FC = () => {
  const SectionTitle: React.FC<{ children: React.ReactNode }> = ({ children }) => (
    <h2 className="mt-12 text-2xl font-bold tracking-tight text-gray-900 sm:text-3xl">{children}</h2>
  );

  const SectionParagraph: React.FC<{ children: React.ReactNode }> = ({ children }) => (
    <p className="mt-4 leading-7">{children}</p>
  );

  const SubHeading: React.FC<{ children: React.ReactNode }> = ({ children }) => (
      <h3 className="mt-6 text-xl font-semibold tracking-tight text-gray-800">{children}</h3>
  );

  return (
    <div className="bg-white px-6 py-24 sm:py-32 lg:px-8">
      <div className="mx-auto max-w-3xl text-base leading-7 text-gray-700">
        <p className="text-base font-semibold leading-7 text-blue-600">Son Güncelleme: 13 Aralık 2025</p>
        <h1 className="mt-2 text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">Çerez Politikası</h1>
        <p className="mt-6 text-xl leading-8">
          FINOPS AI olarak, web sitemizin ve platformumuzun ("Hizmetler") kullanıcı deneyimini iyileştirmek ve verimli bir şekilde çalışmasını sağlamak için çerezler ve benzeri izleme teknolojileri kullanıyoruz. Bu politika, hangi çerezleri neden ve nasıl kullandığımızı açıklamaktadır.
        </p>

        <div className="mt-10 max-w-2xl">
          <SectionTitle>1. Çerez Nedir?</SectionTitle>
          <SectionParagraph>
            Çerezler, bir web sitesini ziyaret ettiğinizde cihazınıza (bilgisayar, tablet, mobil telefon) kaydedilen küçük metin dosyalarıdır. Çerezler, bir web sitesinin sizi tanımasını, tercihlerinizi hatırlamasını ve genel olarak kullanıcı deneyiminizi geliştirmesini sağlar.
          </SectionParagraph>

          <SectionTitle>2. Kullandığımız Çerez Türleri ve Amaçları</SectionTitle>
          <SectionParagraph>
            Hizmetlerimizde aşağıdaki kategorilerde çerezler kullanmaktayız:
          </SectionParagraph>

          <SubHeading>a. Zorunlu Çerezler</SubHeading>
          <SectionParagraph>
            Bu çerezler, web sitemizin güvenli bir şekilde çalışması ve temel fonksiyonlarının (kullanıcı girişi, form doldurma gibi) yerine getirilebilmesi için mutlak surette gereklidir. Bu çerezler olmadan hizmetlerimiz düzgün çalışmaz.
          </SectionParagraph>

          <SubHeading>b. İşlevsel Çerezler</SubHeading>
          <SectionParagraph>
            Bu çerezler, dil tercihleriniz veya bölge seçiminiz gibi tercihlerinizi hatırlayarak size daha kişiselleştirilmiş bir deneyim sunmamızı sağlar.
          </SectionParagraph>

          <SubHeading>c. Performans ve Analitik Çerezler</SubHeading>
          <SectionParagraph>
            Bu çerezler, ziyaretçilerin sitemizi nasıl kullandığı, hangi sayfaları daha sık ziyaret ettiği ve hata mesajları alıp almadığı gibi bilgileri anonim olarak toplar. Bu bilgileri (örneğin, Google Analytics kullanarak) hizmetlerimizi ve performansımızı iyileştirmek için kullanırız.
          </SectionParagraph>

          <SubHeading>d. Reklam ve Pazarlama Çerezleri</SubHeading>
          <SectionParagraph>
            Bu çerezler, sizin ve ilgi alanlarınızla daha alakalı reklamlar sunmak için kullanılır. Bu çerezler, reklam ortaklarımız (örneğin; Google, LinkedIn) tarafından yerleştirilebilir ve gezinme alışkanlıklarınıza dayalı bir profil oluşturmak için kullanılabilir.
          </SectionParagraph>

          <SectionTitle>3. Çerezleri Nasıl Yönetebilir ve Reddedebilirsiniz?</SectionTitle>
          <SectionParagraph>
            Çerezleri kontrol etme ve yönetme hakkına sahipsiniz. Tarayıcı ayarlarınızı değiştirerek çerezleri silebilir veya engelleyebilirsiniz. Popüler tarayıcılarda çerez yönetimi hakkında bilgi almak için aşağıdaki bağlantıları ziyaret edebilirsiniz:
          </SectionParagraph>
          <ul className="mt-4 list-disc list-inside text-gray-600">
            <li><a href="https://support.google.com/chrome/answer/95647" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">Google Chrome</a></li>
            <li><a href="https://support.mozilla.org/tr/kb/cerezleri-silme-web-sitelerinin-bilgilerini-kaldirma" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">Mozilla Firefox</a></li>
            <li><a href="https://support.microsoft.com/tr-tr/windows/tan%C4%B1mlama-bilgilerini-silme-ve-y%C3%B6netme-168dab11-0753-043d-7c16-ede5947fc64d" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">Microsoft Edge</a></li>
            <li><a href="https://support.apple.com/tr-tr/guide/safari/sfri11471/mac" target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline">Safari</a></li>
          </ul>
          <SectionParagraph>
            Ancak, zorunlu çerezleri engellemenin web sitemizin işlevselliğini olumsuz etkileyebileceğini lütfen unutmayın.
          </SectionParagraph>

          <SectionTitle>4. Diğer Politikalarla İlişki</SectionTitle>
          <SectionParagraph>
            Çerezler aracılığıyla toplanan kişisel veriler, <Link to="/legal/privacy-policy" className="text-blue-600 hover:text-blue-700">Kişisel Verilerin Korunması ve İşlenmesi Politikamız</Link> kapsamında işlenmektedir. Bu politika, çerez politikamızın ayrılmaz bir parçasıdır.
          </SectionParagraph>

          <SectionTitle>5. Bize Ulaşın</SectionTitle>
          <SectionParagraph>
            Çerez politikamızla ilgili herhangi bir sorunuz varsa, lütfen <Link to="/contact" className="text-blue-600 hover:text-blue-700">iletişim sayfamız</Link> üzerinden bizimle irtibata geçin.
          </SectionParagraph>
        </div>
      </div>
    </div>
  );
};

export default CookiePolicyPage;
