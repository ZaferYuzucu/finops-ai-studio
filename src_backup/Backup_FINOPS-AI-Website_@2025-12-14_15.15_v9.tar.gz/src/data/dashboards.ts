
// Görselleri doğrudan içeri aktararak Vite'in dosya yönetimini devralmasını sağlıyoruz.
// Bu, dosya yollarından kaynaklanan hataları tamamen ortadan kaldırır.
import ceoDashboard from '../assets/dashboards/ceo-dashboard.png';
import profitLossDashboard from '../assets/dashboards/profit-and-loss-dashboard.png';
import cashFlowDashboard from '../assets/dashboards/cash-flow-statement-dashboard.png';
import salesTeamPerformanceDashboard from '../assets/dashboards/sales-team-performance-dashboard.png';
import salesKpiDashboard from '../assets/dashboards/sales-kpi-dashboard.png';
import marketingCampaignDashboard from '../assets/dashboards/marketing-campaign-performance-dashboard.png';
import hrDashboard from '../assets/dashboards/hr-dashboard.png';
import inventoryManagementDashboard from '../assets/dashboards/inventory-management-dashboard.png';
import saasKpiDashboard from '../assets/dashboards/saas-kpi-dashboard.png';
import ecommerceDashboard from '../assets/dashboards/ecommerce-dashboard.png';

export interface Dashboard {
  id: string;
  name: string;
  category: string;
  description: string;
  longDescription: string;
  imageUrl: string; // Bu tip hala string, çünkü import edilen asset bir string yoluna çözümlenir.
}

export const dashboardCategories = [
  "Tümü",
  "Finans",
  "Satış",
  "Pazarlama",
  "İK",
  "Operasyon",
  "Proje Yönetimi",
  "Sektörel",
];

export const dashboards: Dashboard[] = [
    // Finans
    {
        id: "ceo-dashboard",
        name: "CEO Bütünsel Bakış Paneli",
        category: "Finans",
        description: "Şirketin genel finansal ve operasyonel sağlığını tek bir ekranda izleyin. Kâr, gelir ve maliyet metriklerine anında ulaşın.",
        longDescription: "CEO Paneli, yöneticilere şirketin nabzını tutma imkanı sunar. Gerçek zamanlı verilerle gelir akışlarını, gider kalemlerini, kârlılık oranlarını ve temel performans göstergelerini (KPI) bir araya getirir. Stratejik karar alma süreçlerini desteklemek için tasarlanmıştır.",
        imageUrl: ceoDashboard, // Statik yol yerine import edilen değişkeni kullanıyoruz.
    },
    {
        id: "profit-loss",
        name: "Kar ve Zarar Analizi",
        category: "Finans",
        description: "Gelir tablolarınızı dinamik olarak analiz edin, gider kalemlerini inceleyin ve kârlılık oranlarınızı anlık olarak takip edin.",
        longDescription: "Bu pano, şirketin belirli bir dönemdeki finansal performansını detaylı bir şekilde analiz eder. Gelirler, satılan malların maliyeti (COGS), brüt kâr, işletme giderleri ve net kâr gibi kalemleri görselleştirerek, finansal sağlığın derinlemesine anlaşılmasını sağlar.",
        imageUrl: profitLossDashboard,
    },
    {
        id: "cash-flow",
        name: "Nakit Akışı Performansı",
        category: "Finans",
        description: "Nakit giriş ve çıkışlarınızı izleyerek, gelecekteki nakit pozisyonunuzu tahmin edin ve likidite risklerinizi yönetin.",
        longDescription: "İşletmenin can damarı olan nakit akışını yönetin. Operasyonel, yatırım ve finansman faaliyetlerinden kaynaklanan nakit hareketlerini izleyin, darboğazları tespit edin ve sağlıklı bir nakit yönetimi stratejisi oluşturun.",
        imageUrl: cashFlowDashboard,
    },
    // Satış
    {
        id: "sales-team-performance",
        name: "Satış Ekibi Performans Paneli",
        category: "Satış",
        description: "Satış temsilcilerinizin performansını, hedeflerini ve kota tamamlama oranlarını gerçek zamanlı olarak takip edin.",
        longDescription: "Satış ekibinizin bireysel ve takım bazındaki performansını ölçün. Yapılan satış adedi, ulaşılan ciro, yeni kazanılan müşteri sayısı ve aktivite metrikleri gibi KPI'larla ekibinizi daha etkin yönetin ve motive edin.",
        imageUrl: salesTeamPerformanceDashboard,
    },
    {
        id: "sales-kpi",
        name: "Satış KPI ve Hedef Takibi",
        category: "Satış",
        description: "Anlaşma büyüklüğü, dönüşüm oranları ve satış döngüsü uzunluğu gibi temel KPI'ları izleyerek satış stratejinizi optimize edin.",
        longDescription: "Satış huninizin (funnel) her aşamasını analiz edin. Potansiyel müşterilerden kapanan anlaşmalara kadar tüm süreci izleyin, dönüşüm oranlarını optimize edin ve satış döngüsünün nerede yavaşladığını tespit ederek iyileştirmeler yapın.",
        imageUrl: salesKpiDashboard,
    },
    // Pazarlama
    {
        id: "marketing-campaign",
        name: "Pazarlama Kampanya Paneli",
        category: "Pazarlama",
        description: "Pazarlama kampanyalarınızın yatırım getirisini (ROI), müşteri edinme maliyetini (CAC) ve etkileşim oranlarını analiz edin.",
        longDescription: "Dijital pazarlama kampanyalarınızın etkinliğini ölçün. Google Ads, sosyal medya veya e-posta pazarlama kanallarından gelen trafiği, potansiyel müşterileri ve yatırım getirisini (ROI) tek bir yerden takip edin.",
        imageUrl: marketingCampaignDashboard,
    },
    // İK
    {
        id: "hr-metrics",
        name: "İK Metrikleri ve Personel Analizi",
        category: "İK",
        description: "İşe alım, personel devir oranı (turnover), çalışan memnuniyeti ve yetenek yönetimi metriklerini tek bir yerden izleyin.",
        longDescription: "İnsan kaynakları departmanınızın stratejik bir ortağa dönüşmesini sağlayın. İşe alım süreleri, personel devir oranı, çalışan başına düşen gelir ve eğitim etkinliği gibi metriklerle insan sermayenizi daha verimli yönetin.",
        imageUrl: hrDashboard,
    },
    // Operasyon
    {
        id: "inventory-management",
        name: "Envanter Yönetim Paneli",
        category: "Operasyon",
        description: "Stok seviyelerinizi, envanter devir hızını ve depo maliyetlerinizi optimize ederek operasyonel verimliliği artırın.",
        longDescription: "Envanter yönetiminizi optimize edin. Stok seviyelerini, sipariş noktalarını, envanter devir hızını ve stokta kalma sürelerini izleyerek hem maliyetleri düşürün hem de müşteri taleplerini zamanında karşılayın.",
        imageUrl: inventoryManagementDashboard,
    },
    // Sektörel
    {
        id: "saas-kpi",
        name: "SaaS KPI Paneli (MRR, Churn)",
        category: "Sektörel",
        description: "Aylık yinelenen gelir (MRR), müşteri kayıp oranı (Churn) ve müşteri yaşam boyu değeri (LTV) gibi SaaS metriklerini takip edin.",
        longDescription: "SaaS (Hizmet Olarak Yazılım) iş modeliniz için hayati metrikleri izleyin. MRR, Churn, LTV, CAC gibi temel performans göstergeleriyle şirketinizin büyüme potansiyelini ve sağlığını analiz edin.",
        imageUrl: saasKpiDashboard,
    },
    {
        id: "ecommerce-sales",
        name: "E-Ticaret Satış Paneli",
        category: "Sektörel",
        description: "Ortalama sepet tutarı, dönüşüm oranları ve en çok satan ürünler gibi e-ticaret verilerini analiz ederek satışlarınızı artırın.",
        longDescription: "E-ticaret sitenizin performansını en ince ayrıntısına kadar analiz edin. Ziyaretçi sayısı, dönüşüm oranı, ortalama sepet tutarı, terk edilen sepetler ve en popüler ürünler gibi verilerle satış stratejilerinizi geliştirin.",
        imageUrl: ecommerceDashboard,
    },
];
