# Footer Sloganı

KOBİ'ler için veri odaklı finans ve operasyon yönetimi platformu.
